SHIVA NUMBERDAR website

Files:
- index.html: Royal Black & Gold personal website with address, Instagram and YouTube links.

Publish using your existing GitHub repository:
1. Open https://github.com/Shiva79066/shiva-numberdar
2. Upload index.html to the repository's main/root folder (replace the older index.html if asked).
3. Commit the changes.
4. In Settings > Pages, select Deploy from a branch, branch main, folder /(root), then Save.
5. Your site address is https://shiva79066.github.io/shiva-numberdar/

The website currently displays:
Village: Nayagoan
Post: Ramraj
Instagram: @shiva_numberdar_04
YouTube: @spicy_animation_1
